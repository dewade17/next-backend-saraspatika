'use client';

import React from 'react';
import AbsensiByRolePage from '@/app/(view)/home/(absensi)/AbsensiByRolePage.jsx';

export default function AbsensiGuruPage() {
  return (
    <AbsensiByRolePage
      title='Absensi Guru'
      role='GURU'
    />
  );
}

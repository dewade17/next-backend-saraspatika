'use client';

import React from 'react';
import AbsensiByRolePage from '@/app/(view)/home/(absensi)/AbsensiByRolePage.jsx';

export default function AbsensiPegawaiPage() {
  return (
    <AbsensiByRolePage
      title='Absensi Pegawai'
      role='PEGAWAI'
    />
  );
}

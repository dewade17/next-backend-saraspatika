'use client';

import React from 'react';
import dayjs from 'dayjs';
import { Select, DatePicker, Typography, Space } from 'antd';

import AppButton from '@/app/(view)/components_shared/AppButton.jsx';
import AppFlex from '@/app/(view)/components_shared/AppFlex.jsx';

const { Text } = Typography;

function buildMonthOptions(anchor) {
  const base = dayjs(anchor || dayjs());
  const year = base.year();
  const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

  return months.map((m, idx) => ({
    value: `${year}-${String(idx + 1).padStart(2, '0')}`,
    label: m,
  }));
}

export default function ShiftGridToolbar({ monthAnchor, onPickMonth, onPrevWeek, onNextWeek, weekStart, weekDates, divisiOptions, jabatanOptions, selectedDivisi, selectedJabatan, setSelectedDivisi, setSelectedJabatan }) {
  const monthOptions = React.useMemo(() => buildMonthOptions(monthAnchor), [monthAnchor]);

  return (
    <div className='w-full'>
      <AppFlex
        align='start'
        gap={20}
        style={{ width: '100%' }}
      >
        <div className='flex flex-wrap items-center gap-2'>
          <Select
            value={selectedDivisi}
            onChange={setSelectedDivisi}
            options={divisiOptions}
            className='min-w-[180px]'
            size='middle'
          />
          <Select
            value={selectedJabatan}
            onChange={setSelectedJabatan}
            options={jabatanOptions}
            className='min-w-[180px]'
            size='middle'
          />
        </div>

        <div className='flex flex-wrap items-center gap-2'>
          <AppButton onClick={onPrevWeek}>
            <span className='px-2'>‹</span> Minggu sebelumnya
          </AppButton>
          <AppButton
            type='primary'
            onClick={onNextWeek}
          >
            Minggu berikutnya <span className='px-2'>›</span>
          </AppButton>

          <DatePicker
            picker='month'
            value={dayjs(monthAnchor)}
            onChange={(v) => {
              if (!v) return;
              onPickMonth(dayjs(v).startOf('month'));
            }}
            className='min-w-[140px]'
            format='YYYY-MM'
          />
        </div>
      </AppFlex>
    </div>
  );
}
